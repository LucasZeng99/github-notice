# github-notice
a chrome extension to send you following users' activities
