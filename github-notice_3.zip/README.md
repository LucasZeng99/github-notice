## Github Notice

This is a chrome extension providing you a shortcut to what people are doing on github, with just one click.

## example

see activities with simple scrolling down
![example](https://github.com/LucasZeng99/github-notice/blob/master/example.png)

add users you want to follow, or import your followings from github
![example2](https://github.com/LucasZeng99/github-notice/blob/master/example2.png)

## notice
This is a project for hackathon "HACKed Beta" and is yet to be published on chrome store.

